//
//  ViewController.swift
//  EggTimer
//
//  Created by Angela Yu on 08/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var progressBar: UIProgressView!
    let softTime = 5
    let medTime = 8
    let hardTime = 12
    
    let eggTimes = ["Soft":300, "Medium":420, "Hard":720]
    var secondsPassed = 0
    var eggTime = 0
    var timer = Timer()
    
    @IBAction func hardnessSelected(_ sender: UIButton) {
        timer.invalidate()
        progressBar.progress = 0.0
        secondsPassed = 0
        let hardness = sender.currentTitle!
        titleLabel.text = hardness
        
        eggTime = eggTimes[hardness]!
        
         timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
           }



        @objc func updateCounter() {
            //example functionality
            if secondsPassed <= eggTime {
                progressBar.progress = Float(secondsPassed)/Float(eggTime)
                secondsPassed += 1
                
            }
            else{
                timer.invalidate()
                titleLabel.text = "Done!"
            }
   
}
    
    
}
